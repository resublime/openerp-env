=============
Miscellanous
=============

.. toctree::
   :maxdepth: 2

   06_misc_on_change_tips.rst
   06_misc_list_font_style.rst
   06_misc_need_action_specs.rst
   06_misc_user_img_specs.rst
   06_misc_import.rst
   06_misc_auto_join.rst
