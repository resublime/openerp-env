from . import test_tax

fast_suite = [test_tax,
              ]
